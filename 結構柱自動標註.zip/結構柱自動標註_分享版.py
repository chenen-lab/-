# -*- coding: utf-8 -*-
"""結構柱自動標註：Revit 2022+ / IronPython 2.7。
在 pyRevit 或 RevitPythonShell 執行，不是一般 Python 程式。
處理目前平面視圖、本文件的結構柱；不含連結模型及建築柱。
"""
import os
import platform
import re
import math
import clr
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import TaskDialog

# 可攜式族群路徑：先找程式旁的 RFA，找不到時開啟選檔視窗。
FAMILY_FILE_NAME = u"-柱標籤(TXT_2.5mm).rfa"


def resolve_family_path():
    script_file = globals().get("__file__")
    if script_file and os.path.isfile(script_file):
        folder = os.path.dirname(os.path.abspath(script_file))
        candidate = os.path.join(folder, FAMILY_FILE_NAME)
        if os.path.isfile(candidate):
            return candidate

    clr.AddReference("System.Windows.Forms")
    from System.Windows.Forms import OpenFileDialog, DialogResult
    dialog = OpenFileDialog()
    try:
        dialog.Title = u"選擇柱標籤族群：" + FAMILY_FILE_NAME
        dialog.Filter = u"Revit 族群 (*.rfa)|*.rfa"
        dialog.FileName = FAMILY_FILE_NAME
        dialog.CheckFileExists = True
        dialog.Multiselect = False
        if dialog.ShowDialog() != DialogResult.OK:
            return None
        return dialog.FileName
    finally:
        dialog.Dispose()
FAMILY_NAME = u"-柱標籤(TXT_2.5mm)"
RECT_TYPE_NAME = u"-柱標籤_cm"
CIRCLE_TYPE_NAME = u"-圓柱標籤(Ø)_cm"
BASE_OFFSET = 300.0 / 304.8
HEAD_SPACING_PAPER_MM = 8.0
# 必要時填入：(u"柱族群名稱", u"柱類型名稱"): "circle" 或 "rect"
SHAPE_OVERRIDES = {}
DIRECTIONS = [(1, 1), (-1, 1), (1, -1), (-1, -1),
              (1, 0), (-1, 0), (0, 1), (0, -1)]


class OverwriteOptions(IFamilyLoadOptions):
    def OnFamilyFound(self, familyInUse, overwriteParameterValues):
        overwriteParameterValues.Value = True
        return True

    def OnSharedFamilyFound(self, sharedFamily, familyInUse,
                            source, overwriteParameterValues):
        source.Value = FamilySource.Family
        overwriteParameterValues.Value = True
        return True


def id_number(eid):
    try:
        return eid.Value
    except AttributeError:
        return eid.IntegerValue


def safe_name(element):
    if element is None:
        return u""
    try:
        return Element.Name.GetValue(element)
    except Exception:
        p = element.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
        return (p.AsString() or u"") if p and p.HasValue else u""


def column_names(doc, column):
    symbol = doc.GetElement(column.GetTypeId())
    family = symbol.Family.Name if isinstance(symbol, FamilySymbol) else u""
    return family, safe_name(symbol)


def normalized_name(name):
    result = re.sub(u"\\s+", u"", name).lower()
    for symbol in (u"ø", u"φ", u"∅"):
        result = result.replace(symbol, u"ø")
    return result


def select_tag_type(symbols, requested):
    exact = [s for s in symbols if safe_name(s) == requested]
    if len(exact) == 1:
        return exact[0]
    matches = [s for s in symbols
               if normalized_name(safe_name(s)) == normalized_name(requested)]
    if len(matches) == 1:
        return matches[0]
    raise Exception(u"無法唯一找到標籤類型：{}\n可用類型：\n{}".format(
        requested, u"\n".join(safe_name(s) for s in symbols)))


def has_diameter(doc, column):
    bip = getattr(BuiltInParameter, "STRUCTURAL_SECTION_COMMON_DIAMETER", None)
    if bip is None:
        return False
    for owner in (column, doc.GetElement(column.GetTypeId())):
        if owner is not None:
            p = owner.get_Parameter(bip)
            if (p is not None and p.HasValue
                    and p.StorageType == StorageType.Double and p.AsDouble() > 0):
                return True
    return False


def collect_solids(geometry):
    solids = []
    if geometry is not None:
        for item in geometry:
            if isinstance(item, Solid):
                if item.Faces.Size > 0 and item.Volume > 1e-9:
                    solids.append(item)
            elif isinstance(item, GeometryInstance):
                solids.extend(collect_solids(item.GetInstanceGeometry()))
    return solids


def regular_circular_solid(solid):
    """完整實心等徑圓柱：同軸側面、兩端面及圓柱體積交叉確認。"""
    cylinders, planes = [], []
    for face in solid.Faces:
        if isinstance(face, CylindricalFace):
            cylinders.append(face)
        elif isinstance(face, PlanarFace):
            planes.append(face)
        else:
            return False
    if not cylinders or len(planes) < 2:
        return False
    first = cylinders[0]
    axis = first.Axis.Normalize()
    origin = first.Origin
    radius = first.get_Radius(0).GetLength()
    tolerance = 0.1 / 304.8
    if radius <= 0:
        return False
    for face in cylinders:
        if abs(face.Axis.Normalize().DotProduct(axis)) < 1.0 - 1e-6:
            return False
        if face.Origin.Subtract(origin).CrossProduct(axis).GetLength() > tolerance:
            return False
        if abs(face.get_Radius(0).GetLength() - radius) > tolerance:
            return False
    caps = []
    for face in planes:
        if abs(face.FaceNormal.Normalize().DotProduct(axis)) < 1.0 - 1e-6:
            return False
        value = face.Origin.Subtract(origin).DotProduct(axis)
        if not any(abs(value - old) <= tolerance for old in caps):
            caps.append(value)
    if len(caps) != 2:
        return False
    height = abs(caps[1] - caps[0])
    if height <= tolerance:
        return False
    expected_volume = math.pi * radius * radius * height
    return abs(solid.Volume - expected_volume) / expected_volume < 0.005


def circle_by_geometry(column):
    options = Options()
    options.ComputeReferences = False
    options.IncludeNonVisibleObjects = False
    options.DetailLevel = ViewDetailLevel.Fine
    try:
        solids = collect_solids(column.get_Geometry(options))
        # 柱帽、底板、多實體及切割造型不靠此規則猜測。
        return len(solids) == 1 and regular_circular_solid(solids[0])
    except Exception as error:
        print(u"[幾何辨識未完成] ID={} | {}".format(id_number(column.Id), error))
        return False
    finally:
        options.Dispose()


def classify_column(doc, column):
    family, typename = column_names(doc, column)
    key = (family, typename)
    if key in SHAPE_OVERRIDES:
        shape = SHAPE_OVERRIDES[key]
        if shape not in ("rect", "circle"):
            raise Exception(u"SHAPE_OVERRIDES 必須填 rect 或 circle。")
        return shape
    text = (family + u" " + typename).lower()
    special = (u"橢圓", u"oval", u"ellipse", u"ellipt", u"h型", u"h形",
               u"i型", u"i形", u"工字", u"十字", u"cross", u"wide flange")
    if any(word in text for word in special):
        return None
    if has_diameter(doc, column):
        return "circle"
    if circle_by_geometry(column):
        print(u"[幾何確認圓柱] ID={} | {} | {}".format(
            id_number(column.Id), family, typename))
        return "circle"
    circle = (any(word in text for word in
                  (u"圓柱", u"圆柱", u"圓形", u"圆形", u"circular", u"round"))
              or re.search(u"[ØøφΦ∅]\\s*\\d|\\b(?:dia(?:meter)?|d)\\s*[=:]?\\s*\\d",
                           text) is not None)
    rectangle = (any(word in text for word in
                     (u"矩形", u"方柱", u"方形", u"rectangular", u"square"))
                 or re.search(u"\\d+(?:\\.\\d+)?\\s*[x×ｘ]\\s*\\d+(?:\\.\\d+)?",
                              typename.lower()) is not None)
    if circle and rectangle:
        return None
    if circle:
        return "circle"
    if rectangle:
        return "rect"
    return None


def column_bounds(column, view):
    bbox = column.get_BoundingBox(view)
    if bbox is None:
        bbox = column.get_BoundingBox(None)
    if bbox is None:
        raise Exception(u"找不到柱的幾何邊界。")
    corners = [bbox.Transform.OfPoint(XYZ(x, y, z))
               for x in (bbox.Min.X, bbox.Max.X)
               for y in (bbox.Min.Y, bbox.Max.Y)
               for z in (bbox.Min.Z, bbox.Max.Z)]
    center = bbox.Transform.OfPoint(bbox.Min.Add(bbox.Max).Multiply(0.5))
    right = [p.DotProduct(view.RightDirection) for p in corners]
    up = [p.DotProduct(view.UpDirection) for p in corners]
    return center, max(max(right) - min(right), max(up) - min(up)) / 2.0 + BASE_OFFSET


def find_position(view, center, offset, placed):
    minimum = HEAD_SPACING_PAPER_MM * view.Scale / 304.8
    for ring in range(6):
        distance = offset + ring * minimum
        for dx, dy in DIRECTIONS:
            candidate = center.Add(view.RightDirection.Multiply(distance * dx)).Add(
                view.UpDirection.Multiply(distance * dy))
            clear = True
            for position in placed:
                delta = candidate.Subtract(position)
                spacing = math.sqrt(delta.DotProduct(view.RightDirection) ** 2
                                    + delta.DotProduct(view.UpDirection) ** 2)
                if spacing < minimum:
                    clear = False
                    break
            if clear:
                return candidate
    raise Exception(u"找不到符合標籤中心間距的位置。")


def main():
    if platform.python_implementation() != "IronPython":
        raise Exception(u"請使用 IronPython 引擎執行此腳本，勿使用 CPython。")
    uidoc = __revit__.ActiveUIDocument
    if uidoc is None:
        raise Exception(u"請先開啟 Revit 專案。")
    doc, view = uidoc.Document, uidoc.Document.ActiveView
    if int(doc.Application.VersionNumber) < 2022:
        raise Exception(u"此分享版需要 Revit 2022 或更新版本。")
    if doc.IsFamilyDocument or doc.IsReadOnly:
        raise Exception(u"請在可編輯的專案文件中執行。")
    if view.IsTemplate or not isinstance(view, ViewPlan):
        raise Exception(u"請切換到要標註的平面視圖。")
    columns = sorted(list(FilteredElementCollector(doc, view.Id)
                          .OfCategory(BuiltInCategory.OST_StructuralColumns)
                          .WhereElementIsNotElementType()),
                     key=lambda c: id_number(c.Id))
    print(u"視圖：{} | 結構柱：{} 支".format(view.Name, len(columns)))
    if not columns:
        TaskDialog.Show(u"結構柱自動標註", u"目前視圖收集到的本文件結構柱：0 支。")
        return
    family_path = resolve_family_path()
    if family_path is None:
        TaskDialog.Show(u"結構柱自動標註", u"已取消選檔，未修改專案。")
        return
    tagged_ids, placed = set(), []
    for tag in (FilteredElementCollector(doc, view.Id).OfClass(IndependentTag)
                .WhereElementIsNotElementType()):
        for eid in tag.GetTaggedLocalElementIds():
            tagged_ids.add(id_number(eid))
        try:
            placed.append(tag.TagHeadPosition)
        except Exception:
            pass
    jobs, unknown, failures = [], [], []
    skipped = 0
    for column in columns:
        if id_number(column.Id) in tagged_ids:
            skipped += 1
            continue
        shape = classify_column(doc, column)
        if shape is None:
            family, typename = column_names(doc, column)
            unknown.append(u"ID={} | 族群={} | 類型={}".format(
                id_number(column.Id), family, typename))
        else:
            jobs.append((column, shape))
    successes = {"rect": 0, "circle": 0}
    transaction = Transaction(doc, u"載入柱標籤及自動標註（圓柱修正版）")
    try:
        if transaction.Start() != TransactionStatus.Started:
            raise Exception(u"無法開始交易。")
        family_ref = clr.Reference[Family]()
        loaded = doc.LoadFamily(family_path, OverwriteOptions(), family_ref)
        if loaded:
            family = family_ref.Value
            if family is None or family.Name != FAMILY_NAME:
                raise Exception(u"RFA 內族群名稱不符；預期：{}，實際：{}".format(
                    FAMILY_NAME, family.Name if family is not None else u"無"))
            load_status = u"族群已載入，允許覆寫既有類型參數值。"
        else:
            load_status = u"未回報重新載入成功，沿用既有族群；可能內容未變更，不宣稱覆寫成功。"
        symbols = [s for s in FilteredElementCollector(doc).OfClass(FamilySymbol)
                   .OfCategory(BuiltInCategory.OST_StructuralColumnTags)
                   if s.Family.Name == FAMILY_NAME]
        if not symbols:
            raise Exception(u"專案中找不到指定的結構柱標籤族群。")
        selected = {}
        needed = set(shape for column, shape in jobs)
        if "rect" in needed:
            selected["rect"] = select_tag_type(symbols, RECT_TYPE_NAME)
        if "circle" in needed:
            selected["circle"] = select_tag_type(symbols, CIRCLE_TYPE_NAME)
        for symbol in selected.values():
            if not symbol.IsActive:
                symbol.Activate()
        doc.Regenerate()
        for column, shape in jobs:
            sub = SubTransaction(doc)
            try:
                if sub.Start() != TransactionStatus.Started:
                    raise Exception(u"無法開始個別柱交易。")
                center, offset = column_bounds(column, view)
                position = find_position(view, center, offset, placed)
                reference = Reference(column)
                tag = IndependentTag.Create(doc, selected[shape].Id, view.Id,
                                            reference, True, TagOrientation.Horizontal, center)
                tag.LeaderEndCondition = LeaderEndCondition.Free
                tag.SetLeaderEnd(reference, center)
                tag.TagHeadPosition = position
                doc.Regenerate()
                text = tag.TagText or u""
                if not text.strip() or u"?" in text or u"？" in text:
                    raise Exception(u"標籤文字為空或含問號，請檢查柱編號／尺寸參數。")
                if sub.Commit() != TransactionStatus.Committed:
                    raise Exception(u"個別柱交易未成功提交。")
                placed.append(position)
                successes[shape] += 1
                print(u"[成功] ID={} | {} | {}".format(
                    id_number(column.Id), safe_name(selected[shape]), text.replace(u"\n", u" / ")))
            except Exception as error:
                if sub.GetStatus() == TransactionStatus.Started:
                    sub.RollBack()
                failures.append(u"ID={} | {} | {}".format(
                    id_number(column.Id), column_names(doc, column)[1], error))
            finally:
                sub.Dispose()
        status = transaction.Commit()
        if status != TransactionStatus.Committed:
            raise Exception(u"整體交易未成功提交，本次標註不列為成功。狀態：{}".format(status))
    except Exception:
        if transaction.GetStatus() == TransactionStatus.Started:
            transaction.RollBack()
        raise
    finally:
        transaction.Dispose()
    for item in unknown:
        print(u"[需確認柱型] " + item)
    for item in failures:
        print(u"[標註失敗] " + item)
    summary = (u"視圖：{}\n\n掃描結構柱：{} 支\n新增標註成功：{} 支\n"
               u"  矩形柱 cm：{} 支\n  圓柱 cm：{} 支\n已有標籤跳過：{} 支\n"
               u"柱型無法判定：{} 支\n標註失敗：{} 支\n\n{}\n\n詳細原因請查看執行輸出。"
               ).format(view.Name, len(columns), sum(successes.values()),
                        successes["rect"], successes["circle"], skipped,
                        len(unknown), len(failures), load_status)
    print(summary)
    TaskDialog.Show(u"結構柱自動標註結果", summary)


try:
    main()
except Exception as error:
    TaskDialog.Show(u"結構柱自動標註未完成", u"{}\n\n未提交的修改會回滾。".format(error))
